<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit;
}

if (isset($_POST['action'])) {
    if ($_POST['action'] == 'approve_appointment') {
        $appointment_id = $_POST['appointment_id'];
        mysqli_query($conn, "UPDATE appointments SET status='Approved' WHERE appointment_id='$appointment_id'");
    } elseif ($_POST['action'] == 'cancel_appointment') {
        $appointment_id = $_POST['appointment_id'];
        mysqli_query($conn, "UPDATE appointments SET status='Cancelled' WHERE appointment_id='$appointment_id'");
    } elseif ($_POST['action'] == 'delete_user') {
        $user_id = $_POST['user_id'];
        mysqli_query($conn, "DELETE FROM users WHERE user_id='$user_id'");
    } elseif ($_POST['action'] == 'add_doctor') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        $full_name = $_POST['full_name'];
        $specialization = $_POST['specialization'];
        $phone = $_POST['phone'];
        $availability = $_POST['availability'];
        
        $user_query = "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$password', 'Doctor')";
        if (mysqli_query($conn, $user_query)) {
            $user_id = mysqli_insert_id($conn);
            $doctor_query = "INSERT INTO doctors (user_id, full_name, specialization, phone, availability) 
                           VALUES ('$user_id', '$full_name', '$specialization', '$phone', '$availability')";
            mysqli_query($conn, $doctor_query);
            $success_message = "Doctor registered successfully!";
        } else {
            $error_message = "Error registering doctor: " . mysqli_error($conn);
        }
    }
}

$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users"))['count'];
$total_doctors = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM doctors"))['count'];
$total_patients = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM patients"))['count'];
$pending_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE status='Pending'"))['count'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - Hospital Management System</title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🏥</text></svg>">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .dashboard-container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); text-align: center; }
        .stat-number { font-size: 2em; font-weight: bold; color: #4A90E2; }
        .admin-header { background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%); color: white; padding: 20px; border-radius: 10px; margin-bottom: 30px; border-left: 5px solid #f0ad4e; }
        .tabs { display: flex; background: white; border-radius: 10px; margin-bottom: 20px; overflow: hidden; }
        .tab { flex: 1; padding: 15px; background: #ecf0f1; cursor: pointer; text-align: center; border: none; }
        .tab.active { background: #4A90E2; color: white; }
        .tab-content { display: none; background: white; padding: 20px; border-radius: 10px; }
        .tab-content.active { display: block; }
        .table { width: 100%; border-collapse: collapse; }
        .table th, .table td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        .table th { background: #f5f5f5; }
        .btn { padding: 5px 10px; margin: 2px; border: none; border-radius: 3px; cursor: pointer; }
        .btn-approve { background: #5cb85c; color: white; }
        .btn-cancel { background: #d9534f; color: white; }
        .btn-delete { background: #f0ad4e; color: white; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="admin-header">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 20px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; background: white; display: flex; align-items: center; justify-content: center; font-size: 2em; color: #2c3e50;">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div>
                        <h2 style="margin: 0;">Admin Dashboard</h2>
                        <p style="margin: 5px 0 0 0; opacity: 0.9;">Welcome, <?php echo $_SESSION['username']; ?>!</p>
                    </div>
                </div>
                <a href="logout.php" class="btn btn-cancel"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card" style="border-left-color: #2c3e50;">
                <div class="stat-number" style="color: #2c3e50;">
                    <i class="fas fa-users"></i> <?php echo $total_users; ?>
                </div>
                <div>Total Users</div>
            </div>
            <div class="stat-card" style="border-left-color: #5cb85c;">
                <div class="stat-number" style="color: #5cb85c;">
                    <i class="fas fa-user-md"></i> <?php echo $total_doctors; ?>
                </div>
                <div>Total Doctors</div>
            </div>
            <div class="stat-card" style="border-left-color: #4A90E2;">
                <div class="stat-number" style="color: #4A90E2;">
                    <i class="fas fa-user-injured"></i> <?php echo $total_patients; ?>
                </div>
                <div>Total Patients</div>
            </div>
            <div class="stat-card" style="border-left-color: #f0ad4e;">
                <div class="stat-number" style="color: #f0ad4e;">
                    <i class="fas fa-clock"></i> <?php echo $pending_appointments; ?>
                </div>
                <div>Pending Appointments</div>
            </div>
        </div>

        <?php if (isset($success_message)): ?>
            <div style="background: #e8f5e9; color: #2e7d32; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        <?php if (isset($error_message)): ?>
            <div style="background: #ffebee; color: #c62828; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <div class="tabs">
            <button class="tab active" onclick="showTab('appointments')">Manage Appointments</button>
            <button class="tab" onclick="showTab('users')">Manage Users</button>
            <button class="tab" onclick="showTab('doctors')">Manage Doctors</button>
            <button class="tab" onclick="showTab('add-doctor')">Add Doctor</button>
            <button class="tab" onclick="showTab('patients')">Manage Patients</button>
        </div>

        <div id="appointments" class="tab-content active">
            <h3>Appointment Management</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $appointments = mysqli_query($conn, "
                        SELECT a.*, p.full_name as patient_name, d.full_name as doctor_name 
                        FROM appointments a 
                        JOIN patients p ON a.patient_id = p.patient_id 
                        JOIN doctors d ON a.doctor_id = d.doctor_id 
                        ORDER BY a.appointment_date DESC
                    ");
                    while ($appointment = mysqli_fetch_assoc($appointments)) {
                        echo "<tr>
                            <td>{$appointment['appointment_id']}</td>
                            <td>{$appointment['patient_name']}</td>
                            <td>{$appointment['doctor_name']}</td>
                            <td>{$appointment['appointment_date']}</td>
                            <td>{$appointment['appointment_time']}</td>
                            <td>{$appointment['status']}</td>
                            <td>";
                        if ($appointment['status'] == 'Pending') {
                            echo "<form method='POST' style='display:inline;'>
                                <input type='hidden' name='appointment_id' value='{$appointment['appointment_id']}'>
                                <button type='submit' name='action' value='approve_appointment' class='btn btn-approve'>Approve</button>
                                <button type='submit' name='action' value='cancel_appointment' class='btn btn-cancel'>Cancel</button>
                            </form>";
                        }
                        echo "</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <div id="users" class="tab-content">
            <h3>User Management</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $users = mysqli_query($conn, "SELECT * FROM users ORDER BY created_at DESC");
                    while ($user = mysqli_fetch_assoc($users)) {
                        echo "<tr>
                            <td>{$user['user_id']}</td>
                            <td>{$user['username']}</td>
                            <td>{$user['email']}</td>
                            <td>{$user['role']}</td>
                            <td>{$user['created_at']}</td>
                            <td>";
                        if ($user['user_id'] != $_SESSION['user_id']) {
                            echo "<form method='POST' style='display:inline;' onsubmit='return confirm(\"Are you sure?\")'>
                                <input type='hidden' name='user_id' value='{$user['user_id']}'>
                                <button type='submit' name='action' value='delete_user' class='btn btn-delete'>Delete</button>
                            </form>";
                        }
                        echo "</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <div id="doctors" class="tab-content">
            <h3>Doctor Management</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Specialization</th>
                        <th>Phone</th>
                        <th>Availability</th>
                        <th>Username</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $doctors = mysqli_query($conn, "
                        SELECT d.*, u.username 
                        FROM doctors d 
                        JOIN users u ON d.user_id = u.user_id
                    ");
                    while ($doctor = mysqli_fetch_assoc($doctors)) {
                        echo "<tr>
                            <td>{$doctor['doctor_id']}</td>
                            <td>{$doctor['full_name']}</td>
                            <td>{$doctor['specialization']}</td>
                            <td>{$doctor['phone']}</td>
                            <td>{$doctor['availability']}</td>
                            <td>{$doctor['username']}</td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <div id="add-doctor" class="tab-content">
            <h3>Add New Doctor</h3>
            <form method="POST" style="max-width: 500px;">
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Username:</label>
                    <input type="text" name="username" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Email:</label>
                    <input type="email" name="email" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Password:</label>
                    <input type="password" name="password" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Full Name:</label>
                    <input type="text" name="full_name" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Specialization:</label>
                    <input type="text" name="specialization" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Phone:</label>
                    <input type="text" name="phone" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Availability:</label>
                    <select name="availability" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px;">
                        <option value="">Select Availability</option>
                        <option value="Mon-Fri 9am-5pm">Mon-Fri 9am-5pm</option>
                        <option value="Mon-Fri 10am-6pm">Mon-Fri 10am-6pm</option>
                        <option value="Tue-Sat 9am-5pm">Tue-Sat 9am-5pm</option>
                        <option value="Wed-Sun 10am-6pm">Wed-Sun 10am-6pm</option>
                        <option value="Mon-Fri 12pm-8pm">Mon-Fri 12pm-8pm</option>
                    </select>
                </div>
                
                <button type="submit" name="action" value="add_doctor" class="btn btn-approve" style="padding: 10px 20px;">
                    Add Doctor
                </button>
            </form>
        </div>

        <div id="patients" class="tab-content">
            <h3>Patient Management</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Age</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Username</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $patients = mysqli_query($conn, "
                        SELECT p.*, u.username 
                        FROM patients p 
                        JOIN users u ON p.user_id = u.user_id
                    ");
                    while ($patient = mysqli_fetch_assoc($patients)) {
                        echo "<tr>
                            <td>{$patient['patient_id']}</td>
                            <td>{$patient['full_name']}</td>
                            <td>{$patient['gender']}</td>
                            <td>{$patient['age']}</td>
                            <td>{$patient['phone']}</td>
                            <td>{$patient['address']}</td>
                            <td>{$patient['username']}</td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
    function showTab(tabName) {
        var contents = document.getElementsByClassName('tab-content');
        for (var i = 0; i < contents.length; i++) {
            contents[i].classList.remove('active');
        }
        
        var tabs = document.getElementsByClassName('tab');
        for (var i = 0; i < tabs.length; i++) {
            tabs[i].classList.remove('active');
        }
        
        document.getElementById(tabName).classList.add('active');
        event.target.classList.add('active');
    }
    </script>
</body>
</html>