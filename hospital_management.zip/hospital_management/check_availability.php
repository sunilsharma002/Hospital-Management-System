<?php
include 'db_connect.php';

if (isset($_POST['email'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    $query = "SELECT email FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) > 0) {
        echo "<span style='color: red; font-size: 12px;'><i class='fas fa-times'></i> Email already exists</span>";
    } else {
        echo "<span style='color: green; font-size: 12px;'><i class='fas fa-check'></i> Email available</span>";
    }
}

if (isset($_POST['username'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    
    $query = "SELECT username FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) > 0) {
        echo "<span style='color: red; font-size: 12px;'><i class='fas fa-times'></i> Username already taken</span>";
    } else {
        echo "<span style='color: green; font-size: 12px;'><i class='fas fa-check'></i> Username available</span>";
    }
}
?>