<?php
include 'db_connect.php';

if (isset($_POST['specialization'])) {
    $specialization = mysqli_real_escape_string($conn, $_POST['specialization']);
    
    $query = "SELECT * FROM doctors WHERE specialization = '$specialization' ORDER BY full_name";
    $result = mysqli_query($conn, $query);
    
    echo '<option value="">Select Doctor</option>';
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<option value="' . $row['doctor_id'] . '" data-availability="' . $row['availability'] . '">';
        echo htmlentities($row['full_name']) . ' - ' . htmlentities($row['specialization']);
        echo '</option>';
    }
}

if (isset($_POST['doctor_id'])) {
    $doctor_id = mysqli_real_escape_string($conn, $_POST['doctor_id']);
    
    $query = "SELECT * FROM doctors WHERE doctor_id = '$doctor_id'";
    $result = mysqli_query($conn, $query);
    
    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode([
            'name' => $row['full_name'],
            'specialization' => $row['specialization'],
            'availability' => $row['availability'],
            'phone' => $row['phone']
        ]);
    }
}
?>