<?php
session_start();
include 'db_connect.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        if (md5($password) === $user['password']) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['username'] = $user['username'];
            
            if ($user['role'] == 'Admin') {
                header("Location: admin_dashboard.php");
                exit();
            } elseif ($user['role'] == 'Doctor') {
                header("Location: doctor_dashboard.php");
                exit();
            } elseif ($user['role'] == 'Patient') {
                header("Location: user_dashboard.php");
                exit();
            }
        } else {
            echo "<script>alert('Invalid password');</script>";
        }
    } else {
        echo "<script>alert('User not found');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login - Hospital Management System</title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🏥</text></svg>">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .form-page {
            background: linear-gradient(135deg, rgba(74, 144, 226, 0.1) 0%, rgba(92, 184, 92, 0.1) 100%),
                        url('https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=1920') center/cover fixed;
        }
        .login-header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: inline-block;
        }
        .login-header i {
            font-size: 3em;
            color: #4A90E2;
            margin-bottom: 10px;
        }
    </style>
</head>
<body class="form-page">
    <div class="login-header">
        <i class="fas fa-hospital"></i>
        <h2 style="margin: 10px 0 5px 0;"><i class="fas fa-sign-in-alt"></i> Hospital Management System</h2>
        <p style="color: #7f8c8d; margin: 0;">Please login to access your dashboard</p>
    </div>
    <form method="POST">
        <label>Username:</label><br>
        <input type="text" name="username" required><br>
        
        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>
        
        <button type="submit" name="login">Login</button>
    </form>
    <div style="text-align: center; margin-top: 20px;">
        <p>New user? <a href="register.php" style="color: #4A90E2; text-decoration: none;">Register here</a></p>
        <p><a href="index.php" style="color: #7f8c8d; text-decoration: none; font-size: 14px;">
            <i class="fas fa-home"></i> Back to Home
        </a></p>
    </div>
</body>
</html>