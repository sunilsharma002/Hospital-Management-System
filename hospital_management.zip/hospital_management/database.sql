
CREATE DATABASE IF NOT EXISTS hospital_system;
USE hospital_system;


CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'Doctor', 'Patient') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE doctors (
    doctor_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    full_name VARCHAR(100) NOT NULL,
    specialization VARCHAR(100),
    phone VARCHAR(20),
    availability VARCHAR(50),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);


CREATE TABLE patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    full_name VARCHAR(100) NOT NULL,
    gender ENUM('Male', 'Female', 'Other'),
    age INT,
    phone VARCHAR(20),
    address VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);


CREATE TABLE appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT,
    doctor_id INT,
    appointment_date DATE,
    appointment_time TIME,
    status ENUM('Pending', 'Approved', 'Cancelled') DEFAULT 'Pending',
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON DELETE CASCADE
);


CREATE TABLE medical_records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id INT,
    diagnosis TEXT,
    treatment TEXT,
    doctor_notes TEXT,
    date_recorded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id) ON DELETE CASCADE
);


INSERT INTO users (username, email, password, role)
VALUES ('admin', 'admin@hospital.com', MD5('admin123'), 'Admin');


INSERT INTO users (username, email, password, role) VALUES
('dr_rao', 'rao@hospital.com', MD5('doc123'), 'Doctor'),
('dr_verma', 'verma@hospital.com', MD5('doc123'), 'Doctor'),
('dr_kapoor', 'kapoor@hospital.com', MD5('doc123'), 'Doctor'),
('dr_singh', 'singh@hospital.com', MD5('doc123'), 'Doctor'),
('dr_kumar', 'kumar@hospital.com', MD5('doc123'), 'Doctor'),
('dr_sharma', 'sharma@hospital.com', MD5('doc123'), 'Doctor'),
('dr_patel', 'patel@hospital.com', MD5('doc123'), 'Doctor'),
('dr_mehta', 'mehta@hospital.com', MD5('doc123'), 'Doctor'),
('dr_gupta', 'gupta@hospital.com', MD5('doc123'), 'Doctor'),
('dr_nanda', 'nanda@hospital.com', MD5('doc123'), 'Doctor');


INSERT INTO doctors (user_id, full_name, specialization, phone, availability) VALUES
(2,'Dr. Rakesh Rao','Cardiologist','9876543210','Mon-Fri 10am-5pm'),
(3,'Dr. Anita Verma','Dermatologist','9876543211','Tue-Sat 11am-6pm'),
(4,'Dr. Rahul Kapoor','Orthopedic','9876543212','Mon-Fri 9am-4pm'),
(5,'Dr. Neha Singh','Gynecologist','9876543213','Wed-Sun 10am-5pm'),
(6,'Dr. Arjun Kumar','Neurologist','9876543214','Mon-Fri 12pm-7pm'),
(7,'Dr. Priya Sharma','Pediatrician','9876543215','Tue-Sat 9am-3pm'),
(8,'Dr. Rajesh Patel','ENT Specialist','9876543216','Mon-Fri 10am-6pm'),
(9,'Dr. Meena Mehta','Dentist','9876543217','Tue-Sun 10am-5pm'),
(10,'Dr. Karan Gupta','Psychiatrist','9876543218','Mon-Fri 11am-4pm'),
(11,'Dr. Sandeep Nanda','Oncologist','9876543219','Mon-Fri 9am-2pm');


INSERT INTO users (username, email, password, role) VALUES
('john', 'john@gmail.com', MD5('patient123'), 'Patient'),
('ravi', 'ravi@gmail.com', MD5('patient123'), 'Patient'),
('priya', 'priya@gmail.com', MD5('patient123'), 'Patient'),
('aman', 'aman@gmail.com', MD5('patient123'), 'Patient'),
('tina', 'tina@gmail.com', MD5('patient123'), 'Patient'),
('rahul', 'rahul@gmail.com', MD5('patient123'), 'Patient'),
('sneha', 'sneha@gmail.com', MD5('patient123'), 'Patient'),
('karan', 'karan@gmail.com', MD5('patient123'), 'Patient'),
('meena', 'meena@gmail.com', MD5('patient123'), 'Patient'),
('deepak', 'deepak@gmail.com', MD5('patient123'), 'Patient');


INSERT INTO patients (user_id, full_name, gender, age, phone, address) VALUES
(12,'John Thomas','Male',28,'987600001','Delhi'),
(13,'Ravi Kumar','Male',35,'987600002','Jalandhar'),
(14,'Priya Sharma','Female',26,'987600003','Amritsar'),
(15,'Aman Singh','Male',30,'987600004','Ludhiana'),
(16,'Tina Kapoor','Female',22,'987600005','Mumbai'),
(17,'Rahul Mehta','Male',33,'987600006','Chandigarh'),
(18,'Sneha Verma','Female',29,'987600007','Patiala'),
(19,'Karan Arora','Male',31,'987600008','Delhi'),
(20,'Meena Joshi','Female',27,'987600009','Gurgaon'),
(21,'Deepak Malhotra','Male',40,'987600010','Noida');


