# 🏥 Hospital Management System

A clean and modern web-based Hospital Management System built with PHP and MySQL. Features separate dashboards for Admins, Doctors, and Patients with role-based access control.

![PHP](https://img.shields.io/badge/PHP-7.4+-777BB4?style=flat&logo=php&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-5.7+-4479A1?style=flat&logo=mysql&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green.svg)

## ✨ Features

### 👨‍💼 Admin Dashboard
- User management (Add/Edit/Delete doctors and patients)
- Appointment oversight and management
- System statistics and analytics
- Role-based access control

### 👨‍⚕️ Doctor Dashboard
- View and manage appointments
- Access patient records
- Add medical notes and prescriptions
- Update appointment status

### 👤 Patient Dashboard
- Book appointments with doctors
- View medical history
- Search and filter doctors by specialization
- Track appointment status

### 🔐 Security Features
- Secure login system with password hashing
- Role-based access control
- Session management
- SQL injection prevention

### 🎨 Design
- Responsive design (works on desktop, tablet, and mobile)
- Modern UI with smooth animations
- Professional medical theme
- Intuitive user interface

## 🛠️ Tech Stack

- **Frontend**: HTML5, CSS3, JavaScript
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **Icons**: Font Awesome 6.0
- **Images**: Unsplash API (CDN)

## 📋 Requirements

- XAMPP/WAMP/LAMP server
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache Web Server
- Modern web browser (Chrome, Firefox, Safari, Edge)

## 🚀 Installation

### Step 1: Clone the Repository
```bash
git clone https://github.com/yourusername/hospital-management-system.git
cd hospital-management-system
```

### Step 2: Setup Database
1. Start XAMPP/WAMP (Apache + MySQL)
2. Open phpMyAdmin: `http://localhost/phpmyadmin`
3. Create a new database named `hospital_system`
4. Import the `database.sql` file

### Step 3: Configure Database Connection
Edit `db_connect.php` if needed (default settings):
```php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_system";
```

### Step 4: Run the Application
1. Copy project folder to `htdocs/` (XAMPP) or `www/` (WAMP)
2. Visit: `http://localhost/hospital-management-system/`
3. Login with test credentials below

## 🔐 Default Login Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `admin123` |
| Doctor | `dr_rao` | `doc123` |
| Patient | `john` | `patient123` |

**Note**: Change default passwords after first login for security.

## 📁 Project Structure

```
hospital-management-system/
├── index.php                 # Landing page
├── login.php                 # Login page
├── register.php              # Patient registration
├── logout.php                # Logout handler
├── db_connect.php            # Database configuration
├── database.sql              # Database schema and sample data
├── admin_dashboard.php       # Admin panel
├── doctor_dashboard.php      # Doctor panel
├── user_dashboard.php        # Patient panel
├── check_availability.php    # Check doctor availability
├── get_doctors.php           # Fetch doctors by specialization
├── assets/
│   └── style.css            # Main stylesheet
└── README.md                # Documentation
```

## 🎯 Usage

### For Patients
1. Register a new account or login with existing credentials
2. Browse available doctors by specialization
3. Book appointments by selecting date and time
4. View appointment history and status

### For Doctors
1. Login with doctor credentials
2. View scheduled appointments
3. Update appointment status (Confirmed/Completed/Cancelled)
4. Access patient information

### For Admins
1. Login with admin credentials
2. Manage users (doctors and patients)
3. View system statistics
4. Oversee all appointments

## 🔧 Troubleshooting

| Issue | Solution |
|-------|----------|
| Connection failed | Check if MySQL service is running |
| Page not found | Ensure Apache is running and project is in correct folder |
| Login issues | Verify database is imported correctly |
| Blank page | Check PHP error logs in XAMPP/WAMP |

## 📸 Screenshots

*Add screenshots of your application here*

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the project
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Author

Your Name - [@yourusername](https://github.com/yourusername)

## 🙏 Acknowledgments

- Font Awesome for icons
- Unsplash for images
- Bootstrap inspiration for design patterns

## 📧 Contact

For any queries or support, please reach out:
- Email: your.email@example.com
- GitHub: [@yourusername](https://github.com/yourusername)

---

⭐ Star this repo if you find it helpful!