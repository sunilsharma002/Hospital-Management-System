<?php
include 'db_connect.php';

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $role = 'Patient';
    

    $query = "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$password', '$role')";
    if (mysqli_query($conn, $query)) {
        $user_id = mysqli_insert_id($conn);
        

        $full_name = $_POST['full_name'];
        $gender = $_POST['gender'];
        $age = $_POST['age'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        
        $patient_query = "INSERT INTO patients (user_id, full_name, gender, age, phone, address) 
                        VALUES ('$user_id', '$full_name', '$gender', '$age', '$phone', '$address')";
        mysqli_query($conn, $patient_query);
        
        echo "<script>alert('Registration successful! You can now login.'); window.location='login.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register - Hospital Management System</title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🏥</text></svg>">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .form-page {
            background: linear-gradient(135deg, rgba(92, 184, 92, 0.1) 0%, rgba(74, 144, 226, 0.1) 100%),
                        url('https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=1920') center/cover fixed;
        }
        .register-header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: inline-block;
        }
        .register-header i {
            font-size: 3em;
            color: #5cb85c;
            margin-bottom: 10px;
        }
    </style>
</head>
<body class="form-page">
    <div class="register-header">
        <i class="fas fa-user-plus"></i>
        <h2 style="margin: 10px 0 5px 0;">Patient Registration</h2>
        <p style="color: #7f8c8d; margin: 0;">Register as a new patient</p>
    </div>
    <form method="POST" id="registerForm">
        <label>Username:</label><br>
        <input type="text" name="username" required><br>
        
        <label>Email:</label><br>
        <input type="email" name="email" required><br>
        
        <label>Password:</label><br>
        <input type="password" name="password" required><br>
        
        <label>Full Name:</label><br>
        <input type="text" name="full_name" required><br>
        
        <label>Phone:</label><br>
        <input type="text" name="phone" required><br>
        
        <label>Gender:</label><br>
        <select name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select><br>
        
        <label>Age:</label><br>
        <input type="number" name="age" required><br>
        
        <label>Address:</label><br>
        <textarea name="address" rows="3" required></textarea><br>
        
        <br>
        <button type="submit" name="register">Register</button>
    </form>
    

    <div style="text-align: center; margin-top: 20px;">
        <p>Already registered? <a href="login.php" style="color: #4A90E2; text-decoration: none;">Login here</a></p>
        <p><a href="index.php" style="color: #7f8c8d; text-decoration: none; font-size: 14px;">
            <i class="fas fa-home"></i> Back to Home
        </a></p>
    </div>
</body>
</html>