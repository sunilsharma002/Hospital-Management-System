<!DOCTYPE html>
<html>
<head>
    <title>Hospital Management System</title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🏥</text></svg>">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, rgba(74, 144, 226, 0.95) 0%, rgba(53, 122, 189, 0.95) 100%),
                        url('https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1920') center/cover;
            min-height: 500px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .hero-logo {
            font-size: 80px;
            margin-bottom: 20px;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
    </style>
</head>
<body>
    <div class="hero-section">
        <div class="hero-content">
            <div class="hero-logo">
                <i class="fas fa-hospital"></i>
            </div>
            <h1>Hospital Management System</h1>
            <p>Manage your healthcare efficiently with modern technology</p>
            <div class="cta-buttons">
                <a href="register.php" class="cta-btn">
                    <i class="fas fa-user-plus"></i> Register as Patient
                </a>
                <a href="login.php" class="cta-btn">
                    <i class="fas fa-sign-in-alt"></i> Login
                </a>
            </div>
        </div>
    </div>

    <div class="features-section">
        <div class="container">
            <h2>Access Your Dashboard</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon-wrapper">
                        <img src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&h=300&fit=crop" 
                             alt="Patient Portal" class="feature-image">
                        <div class="feature-icon-overlay">
                            <i class="fas fa-user"></i>
                        </div>
                    </div>
                    <h3>Patient Portal</h3>
                    <p>Book appointments and view medical history</p>
                    <a href="register.php" class="btn btn-primary">Register as Patient</a>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon-wrapper">
                        <img src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=300&fit=crop" 
                             alt="Doctor Portal" class="feature-image">
                        <div class="feature-icon-overlay">
                            <i class="fas fa-user-md"></i>
                        </div>
                    </div>
                    <h3>Doctor Portal</h3>
                    <p>Manage patients and appointments<br><small>Doctors are registered by admin</small></p>
                    <a href="login.php" class="btn btn-primary">Doctor Login</a>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon-wrapper">
                        <img src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=400&h=300&fit=crop" 
                             alt="Admin Panel" class="feature-image">
                        <div class="feature-icon-overlay">
                            <i class="fas fa-cog"></i>
                        </div>
                    </div>
                    <h3>Admin Panel</h3>
                    <p>System management and oversight</p>
                    <a href="login.php" class="btn btn-primary">Admin Login</a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Features Showcase Section -->
    <div class="showcase-section">
        <div class="container">
            <h2>Why Choose Our System?</h2>
            <div class="showcase-grid">
                <div class="showcase-item">
                    <i class="fas fa-shield-alt"></i>
                    <h4>Secure & Safe</h4>
                    <p>Your data is protected with advanced security</p>
                </div>
                <div class="showcase-item">
                    <i class="fas fa-clock"></i>
                    <h4>24/7 Access</h4>
                    <p>Access your records anytime, anywhere</p>
                </div>
                <div class="showcase-item">
                    <i class="fas fa-mobile-alt"></i>
                    <h4>Mobile Friendly</h4>
                    <p>Works perfectly on all devices</p>
                </div>
                <div class="showcase-item">
                    <i class="fas fa-chart-line"></i>
                    <h4>Real-time Updates</h4>
                    <p>Get instant notifications and updates</p>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <p>&copy; 2025 Hospital Management System. All rights reserved.</p>
    </footer>
</body>
</html>