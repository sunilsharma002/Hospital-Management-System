<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'Doctor') {
    header("Location: login.php");
    exit;
}


$doctor_query = mysqli_query($conn, "SELECT * FROM doctors WHERE user_id = '{$_SESSION['user_id']}'");
$doctor_info = mysqli_fetch_assoc($doctor_query);
$doctor_id = $doctor_info['doctor_id'];


if (isset($_POST['action'])) {
    if ($_POST['action'] == 'approve_appointment') {
        $appointment_id = $_POST['appointment_id'];
        mysqli_query($conn, "UPDATE appointments SET status='Approved' WHERE appointment_id='$appointment_id'");
    } elseif ($_POST['action'] == 'complete_appointment') {
        $appointment_id = $_POST['appointment_id'];
        mysqli_query($conn, "UPDATE appointments SET status='Completed' WHERE appointment_id='$appointment_id'");
    } elseif ($_POST['action'] == 'cancel_appointment') {
        $appointment_id = $_POST['appointment_id'];
        mysqli_query($conn, "UPDATE appointments SET status='Cancelled' WHERE appointment_id='$appointment_id'");
    } elseif ($_POST['action'] == 'add_medical_record') {
        $appointment_id = $_POST['appointment_id'];
        $diagnosis = mysqli_real_escape_string($conn, $_POST['diagnosis']);
        $treatment = mysqli_real_escape_string($conn, $_POST['treatment']);
        $doctor_notes = mysqli_real_escape_string($conn, $_POST['doctor_notes']);
        
        mysqli_query($conn, "INSERT INTO medical_records (appointment_id, diagnosis, treatment, doctor_notes) 
                           VALUES ('$appointment_id', '$diagnosis', '$treatment', '$doctor_notes')");
        mysqli_query($conn, "UPDATE appointments SET status='Completed' WHERE appointment_id='$appointment_id'");
    }
}


$today = date('Y-m-d');
$today_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE doctor_id='$doctor_id' AND appointment_date='$today'"))['count'];
$pending_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE doctor_id='$doctor_id' AND status='Pending'"))['count'];
$total_patients = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT patient_id) as count FROM appointments WHERE doctor_id='$doctor_id'"))['count'];
$completed_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE doctor_id='$doctor_id' AND status='Completed'"))['count'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Doctor Dashboard</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .dashboard-container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .doctor-header { background: linear-gradient(135deg, #5cb85c 0%, #449d44 100%); color: white; padding: 20px; border-radius: 10px; margin-bottom: 30px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); text-align: center; }
        .stat-number { font-size: 2em; font-weight: bold; color: #5cb85c; }
        .tabs { display: flex; background: white; border-radius: 10px; margin-bottom: 20px; overflow: hidden; }
        .tab { flex: 1; padding: 15px; background: #ecf0f1; cursor: pointer; text-align: center; border: none; }
        .tab.active { background: #5cb85c; color: white; }
        .tab-content { display: none; background: white; padding: 20px; border-radius: 10px; }
        .tab-content.active { display: block; }
        .table { width: 100%; border-collapse: collapse; }
        .table th, .table td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        .table th { background: #f5f5f5; }
        .btn { padding: 5px 10px; margin: 2px; border: none; border-radius: 3px; cursor: pointer; }
        .btn-approve { background: #5cb85c; color: white; }
        .btn-complete { background: #4A90E2; color: white; }
        .btn-cancel { background: #d9534f; color: white; }
        .medical-form { background: #e8f5e9; padding: 15px; border-radius: 5px; margin-top: 10px; border-left: 4px solid #5cb85c; }
        .medical-form textarea { width: 100%; margin: 5px 0; padding: 8px; border: 1px solid #ddd; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Header -->
        <div class="doctor-header">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2>Welcome, Dr. <?php echo $doctor_info['full_name']; ?>!</h2>
                    <p>Specialization: <?php echo $doctor_info['specialization']; ?></p>
                </div>
                <a href="logout.php" class="btn btn-cancel">Logout</a>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card" style="border-left-color: #5cb85c;">
                <div class="stat-number" style="color: #5cb85c;">
                    <i class="fas fa-calendar-day"></i> <?php echo $today_appointments; ?>
                </div>
                <div>Today's Appointments</div>
            </div>
            <div class="stat-card" style="border-left-color: #f0ad4e;">
                <div class="stat-number" style="color: #f0ad4e;">
                    <i class="fas fa-hourglass-half"></i> <?php echo $pending_appointments; ?>
                </div>
                <div>Pending Appointments</div>
            </div>
            <div class="stat-card" style="border-left-color: #4A90E2;">
                <div class="stat-number" style="color: #4A90E2;">
                    <i class="fas fa-users"></i> <?php echo $total_patients; ?>
                </div>
                <div>Total Patients</div>
            </div>
            <div class="stat-card" style="border-left-color: #5cb85c;">
                <div class="stat-number" style="color: #5cb85c;">
                    <i class="fas fa-check-circle"></i> <?php echo $completed_appointments; ?>
                </div>
                <div>Completed Appointments</div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="tabs">
            <button class="tab active" onclick="showTab('appointments')">My Appointments</button>
            <button class="tab" onclick="showTab('patients')">My Patients</button>
            <button class="tab" onclick="showTab('schedule')">Schedule</button>
            <button class="tab" onclick="showTab('profile')">Profile</button>
        </div>

        <!-- Appointments Tab -->
        <div id="appointments" class="tab-content active">
            <h3>Appointment Management</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $appointments = mysqli_query($conn, "
                        SELECT a.*, p.full_name as patient_name, p.phone, p.age 
                        FROM appointments a 
                        JOIN patients p ON a.patient_id = p.patient_id 
                        WHERE a.doctor_id = '$doctor_id' 
                        ORDER BY a.appointment_date DESC, a.appointment_time DESC
                    ");
                    while ($appointment = mysqli_fetch_assoc($appointments)) {
                        echo "<tr>
                            <td>{$appointment['appointment_id']}</td>
                            <td>{$appointment['patient_name']}<br><small>Age: {$appointment['age']}, Phone: {$appointment['phone']}</small></td>
                            <td>{$appointment['appointment_date']}</td>
                            <td>{$appointment['appointment_time']}</td>
                            <td><span class='status-{$appointment['status']}'>{$appointment['status']}</span></td>
                            <td>";
                        
                        if ($appointment['status'] == 'Pending') {
                            echo "<form method='POST' style='display:inline;'>
                                <input type='hidden' name='appointment_id' value='{$appointment['appointment_id']}'>
                                <button type='submit' name='action' value='approve_appointment' class='btn btn-approve'>Approve</button>
                                <button type='submit' name='action' value='cancel_appointment' class='btn btn-cancel'>Cancel</button>
                            </form>";
                        } elseif ($appointment['status'] == 'Approved') {
                            echo "<button onclick='showMedicalForm({$appointment['appointment_id']})' class='btn btn-complete'>Add Medical Record</button>";
                        }
                        
                        echo "</td></tr>";
                        

                        if ($appointment['status'] == 'Approved') {
                            echo "<tr id='medical-form-{$appointment['appointment_id']}' style='display:none;'>
                                <td colspan='6'>
                                    <div class='medical-form'>
                                        <h4>Add Medical Record for {$appointment['patient_name']}</h4>
                                        <form method='POST'>
                                            <input type='hidden' name='appointment_id' value='{$appointment['appointment_id']}'>
                                            <textarea name='diagnosis' placeholder='Diagnosis' rows='3' required></textarea>
                                            <textarea name='treatment' placeholder='Treatment/Prescription' rows='3' required></textarea>
                                            <textarea name='doctor_notes' placeholder='Doctor Notes' rows='2'></textarea>
                                            <button type='submit' name='action' value='add_medical_record' class='btn btn-complete'>Save & Complete</button>
                                            <button type='button' onclick='hideMedicalForm({$appointment['appointment_id']})' class='btn btn-cancel'>Cancel</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Patients Tab -->
        <div id="patients" class="tab-content">
            <h3>My Patients</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Patient Name</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Phone</th>
                        <th>Last Visit</th>
                        <th>Total Visits</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $patients = mysqli_query($conn, "
                        SELECT p.*, 
                               MAX(a.appointment_date) as last_visit,
                               COUNT(a.appointment_id) as total_visits
                        FROM patients p 
                        JOIN appointments a ON p.patient_id = a.patient_id 
                        WHERE a.doctor_id = '$doctor_id' 
                        GROUP BY p.patient_id
                        ORDER BY last_visit DESC
                    ");
                    while ($patient = mysqli_fetch_assoc($patients)) {
                        echo "<tr>
                            <td>{$patient['full_name']}</td>
                            <td>{$patient['age']}</td>
                            <td>{$patient['gender']}</td>
                            <td>{$patient['phone']}</td>
                            <td>{$patient['last_visit']}</td>
                            <td>{$patient['total_visits']}</td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Schedule Tab -->
        <div id="schedule" class="tab-content">
            <h3>My Schedule</h3>
            <div style="background: white; padding: 20px; border-radius: 10px;">
                <h4>Availability: <?php echo $doctor_info['availability']; ?></h4>
                <h4>Today's Schedule (<?php echo date('Y-m-d'); ?>)</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Time</th>
                            <th>Patient</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $today_schedule = mysqli_query($conn, "
                            SELECT a.*, p.full_name as patient_name 
                            FROM appointments a 
                            JOIN patients p ON a.patient_id = p.patient_id 
                            WHERE a.doctor_id = '$doctor_id' AND a.appointment_date = '$today'
                            ORDER BY a.appointment_time
                        ");
                        while ($schedule = mysqli_fetch_assoc($today_schedule)) {
                            echo "<tr>
                                <td>{$schedule['appointment_time']}</td>
                                <td>{$schedule['patient_name']}</td>
                                <td>{$schedule['status']}</td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Profile Tab -->
        <div id="profile" class="tab-content">
            <h3>Doctor Profile</h3>
            <div style="background: white; padding: 20px; border-radius: 10px;">
                <table class="table">
                    <tr><th>Full Name</th><td><?php echo $doctor_info['full_name']; ?></td></tr>
                    <tr><th>Specialization</th><td><?php echo $doctor_info['specialization']; ?></td></tr>
                    <tr><th>Phone</th><td><?php echo $doctor_info['phone']; ?></td></tr>
                    <tr><th>Availability</th><td><?php echo $doctor_info['availability']; ?></td></tr>
                    <tr><th>Username</th><td><?php echo $_SESSION['username']; ?></td></tr>
                </table>
            </div>
        </div>
    </div>

    <script>
    function showTab(tabName) {
        var contents = document.getElementsByClassName('tab-content');
        for (var i = 0; i < contents.length; i++) {
            contents[i].classList.remove('active');
        }
        
        var tabs = document.getElementsByClassName('tab');
        for (var i = 0; i < tabs.length; i++) {
            tabs[i].classList.remove('active');
        }
        
        document.getElementById(tabName).classList.add('active');
        event.target.classList.add('active');
    }

    function showMedicalForm(appointmentId) {
        document.getElementById('medical-form-' + appointmentId).style.display = 'table-row';
    }

    function hideMedicalForm(appointmentId) {
        document.getElementById('medical-form-' + appointmentId).style.display = 'none';
    }
    </script>
</body>
</html>