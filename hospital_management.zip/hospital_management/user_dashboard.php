<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'User' && $_SESSION['role'] != 'Patient')) {
    header("Location: login.php");
    exit;
}


$patient_query = mysqli_query($conn, "SELECT * FROM patients WHERE user_id = '{$_SESSION['user_id']}'");
$patient_info = mysqli_fetch_assoc($patient_query);
$patient_id = $patient_info['patient_id'];


if (isset($_POST['book_appointment'])) {
    $doctor_id = $_POST['doctor_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    

    $check_slot = mysqli_query($conn, "SELECT * FROM appointments WHERE doctor_id='$doctor_id' AND appointment_date='$appointment_date' AND appointment_time='$appointment_time' AND status != 'Cancelled'");
    
    if (mysqli_num_rows($check_slot) == 0) {
        $insert_appointment = mysqli_query($conn, "INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, status) VALUES ('$patient_id', '$doctor_id', '$appointment_date', '$appointment_time', 'Pending')");
        if ($insert_appointment) {
            $success_message = "Appointment booked successfully!";
        } else {
            $error_message = "Failed to book appointment. Please try again.";
        }
    } else {
        $error_message = "This time slot is already booked. Please choose another time.";
    }
}


if (isset($_POST['cancel_appointment'])) {
    $appointment_id = $_POST['appointment_id'];
    mysqli_query($conn, "UPDATE appointments SET status='Cancelled' WHERE appointment_id='$appointment_id' AND patient_id='$patient_id'");
    $success_message = "Appointment cancelled successfully.";
}


$total_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE patient_id='$patient_id'"))['count'];
$pending_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE patient_id='$patient_id' AND status='Pending'"))['count'];
$completed_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE patient_id='$patient_id' AND status='Completed'"))['count'];
$upcoming_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE patient_id='$patient_id' AND appointment_date >= CURDATE() AND status IN ('Pending', 'Approved')"))['count'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Dashboard</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .dashboard-container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .patient-header { background: linear-gradient(135deg, #4A90E2 0%, #357ABD 100%); color: white; padding: 20px; border-radius: 10px; margin-bottom: 30px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); text-align: center; }
        .stat-number { font-size: 2em; font-weight: bold; color: #4A90E2; }
        .tabs { display: flex; background: white; border-radius: 10px; margin-bottom: 20px; overflow: hidden; }
        .tab { flex: 1; padding: 15px; background: #ecf0f1; cursor: pointer; text-align: center; border: none; }
        .tab.active { background: #4A90E2; color: white; }
        .tab-content { display: none; background: white; padding: 20px; border-radius: 10px; }
        .tab-content.active { display: block; }
        .table { width: 100%; border-collapse: collapse; }
        .table th, .table td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        .table th { background: #f5f5f5; }
        .btn { padding: 8px 15px; margin: 2px; border: none; border-radius: 3px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-primary { background: #4A90E2; color: white; }
        .btn-danger { background: #d9534f; color: white; }
        .btn-info { background: #5bc0de; color: white; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group select, .form-group input { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .alert-success { background: #e8f5e9; color: #2e7d32; border: 1px solid #c8e6c9; }
        .alert-danger { background: #ffebee; color: #c62828; border: 1px solid #ef9a9a; }
        .doctor-card { background: #e8f5e9; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #5cb85c; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .doctor-card h4 { color: #2c3e50; margin-top: 0; }
        .doctor-card strong { color: #5cb85c; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Header -->
        <div class="patient-header">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2>Welcome, <?php echo $patient_info['full_name']; ?>!</h2>
                    <p>Patient ID: <?php echo $patient_info['patient_id']; ?></p>
                </div>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
        </div>

        <!-- Messages -->
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card" style="border-left-color: #4A90E2;">
                <div class="stat-number" style="color: #4A90E2;">
                    <i class="fas fa-calendar-alt"></i> <?php echo $total_appointments; ?>
                </div>
                <div>Total Appointments</div>
            </div>
            <div class="stat-card" style="border-left-color: #5cb85c;">
                <div class="stat-number" style="color: #5cb85c;">
                    <i class="fas fa-calendar-check"></i> <?php echo $upcoming_appointments; ?>
                </div>
                <div>Upcoming Appointments</div>
            </div>
            <div class="stat-card" style="border-left-color: #f0ad4e;">
                <div class="stat-number" style="color: #f0ad4e;">
                    <i class="fas fa-clock"></i> <?php echo $pending_appointments; ?>
                </div>
                <div>Pending Appointments</div>
            </div>
            <div class="stat-card" style="border-left-color: #4A90E2;">
                <div class="stat-number" style="color: #4A90E2;">
                    <i class="fas fa-check-double"></i> <?php echo $completed_appointments; ?>
                </div>
                <div>Completed Visits</div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="tabs">
            <button class="tab active" onclick="showTab('book-appointment')">Book Appointment</button>
            <button class="tab" onclick="showTab('my-appointments')">My Appointments</button>
            <button class="tab" onclick="showTab('medical-history')">Medical History</button>
            <button class="tab" onclick="showTab('profile')">My Profile</button>
        </div>

        <!-- Book Appointment Tab -->
        <div id="book-appointment" class="tab-content active">
            <h3>Book New Appointment</h3>
            <form method="POST">
                <div class="form-group">
                    <label>Select Doctor:</label>
                    <select name="doctor_id" id="doctor_select" onchange="showDoctorInfo()" required>
                        <option value="">Choose a doctor...</option>
                        <?php
                        $doctors = mysqli_query($conn, "SELECT * FROM doctors ORDER BY specialization, full_name");
                        while ($doctor = mysqli_fetch_assoc($doctors)) {
                            echo "<option value='{$doctor['doctor_id']}' data-specialization='{$doctor['specialization']}' data-availability='{$doctor['availability']}'>{$doctor['full_name']} - {$doctor['specialization']}</option>";
                        }
                        ?>
                    </select>
                </div>
                
                <div id="doctor-info" style="display: none;" class="doctor-card">
                    <h4 id="doctor-name"></h4>
                    <p><strong>Specialization:</strong> <span id="doctor-specialization"></span></p>
                    <p><strong>Available:</strong> <span id="doctor-availability"></span></p>
                </div>

                <div class="form-group">
                    <label>Appointment Date:</label>
                    <input type="date" name="appointment_date" min="<?php echo date('Y-m-d'); ?>" required>
                </div>

                <div class="form-group">
                    <label>Appointment Time:</label>
                    <select name="appointment_time" required>
                        <option value="">Select time...</option>
                        <option value="09:00:00">9:00 AM</option>
                        <option value="10:00:00">10:00 AM</option>
                        <option value="11:00:00">11:00 AM</option>
                        <option value="12:00:00">12:00 PM</option>
                        <option value="14:00:00">2:00 PM</option>
                        <option value="15:00:00">3:00 PM</option>
                        <option value="16:00:00">4:00 PM</option>
                        <option value="17:00:00">5:00 PM</option>
                    </select>
                </div>

                <button type="submit" name="book_appointment" class="btn btn-primary">Book Appointment</button>
            </form>
        </div>

        <!-- My Appointments Tab -->
        <div id="my-appointments" class="tab-content">
            <h3>My Appointments</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Doctor</th>
                        <th>Specialization</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $appointments = mysqli_query($conn, "
                        SELECT a.*, d.full_name as doctor_name, d.specialization 
                        FROM appointments a 
                        JOIN doctors d ON a.doctor_id = d.doctor_id 
                        WHERE a.patient_id = '$patient_id' 
                        ORDER BY a.appointment_date DESC, a.appointment_time DESC
                    ");
                    while ($appointment = mysqli_fetch_assoc($appointments)) {
                        $status_class = strtolower($appointment['status']);
                        echo "<tr>
                            <td>{$appointment['appointment_id']}</td>
                            <td>{$appointment['doctor_name']}</td>
                            <td>{$appointment['specialization']}</td>
                            <td>{$appointment['appointment_date']}</td>
                            <td>" . date('h:i A', strtotime($appointment['appointment_time'])) . "</td>
                            <td><span class='status-{$status_class}'>{$appointment['status']}</span></td>
                            <td>";
                        
                        if ($appointment['status'] == 'Pending' && $appointment['appointment_date'] >= date('Y-m-d')) {
                            echo "<form method='POST' style='display:inline;' onsubmit='return confirm(\"Are you sure you want to cancel this appointment?\")'>
                                <input type='hidden' name='appointment_id' value='{$appointment['appointment_id']}'>
                                <button type='submit' name='cancel_appointment' class='btn btn-danger'>Cancel</button>
                            </form>";
                        }
                        
                        echo "</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Medical History Tab -->
        <div id="medical-history" class="tab-content">
            <h3>Medical History</h3>
            <?php
            $medical_records = mysqli_query($conn, "
                SELECT mr.*, a.appointment_date, d.full_name as doctor_name, d.specialization 
                FROM medical_records mr 
                JOIN appointments a ON mr.appointment_id = a.appointment_id 
                JOIN doctors d ON a.doctor_id = d.doctor_id 
                WHERE a.patient_id = '$patient_id' 
                ORDER BY mr.date_recorded DESC
            ");
            
            if (mysqli_num_rows($medical_records) > 0) {
                while ($record = mysqli_fetch_assoc($medical_records)) {
                    echo "<div class='doctor-card'>
                        <h4>Visit on " . date('M d, Y', strtotime($record['appointment_date'])) . "</h4>
                        <p><strong>Doctor:</strong> {$record['doctor_name']} ({$record['specialization']})</p>
                        <p><strong>Diagnosis:</strong> {$record['diagnosis']}</p>
                        <p><strong>Treatment:</strong> {$record['treatment']}</p>";
                    if (!empty($record['doctor_notes'])) {
                        echo "<p><strong>Doctor's Notes:</strong> {$record['doctor_notes']}</p>";
                    }
                    echo "<p><small><strong>Recorded:</strong> " . date('M d, Y h:i A', strtotime($record['date_recorded'])) . "</small></p>
                    </div>";
                }
            } else {
                echo "<p>No medical records found.</p>";
            }
            ?>
        </div>

        <!-- Profile Tab -->
        <div id="profile" class="tab-content">
            <h3>My Profile</h3>
            <div style="background: white; padding: 20px; border-radius: 10px;">
                <table class="table">
                    <tr><th>Full Name</th><td><?php echo $patient_info['full_name']; ?></td></tr>
                    <tr><th>Gender</th><td><?php echo $patient_info['gender']; ?></td></tr>
                    <tr><th>Age</th><td><?php echo $patient_info['age']; ?></td></tr>
                    <tr><th>Phone</th><td><?php echo $patient_info['phone']; ?></td></tr>
                    <tr><th>Address</th><td><?php echo $patient_info['address']; ?></td></tr>
                    <tr><th>Username</th><td><?php echo $_SESSION['username']; ?></td></tr>
                </table>
            </div>
        </div>
    </div>

    <script>
    function showTab(tabName) {
        var contents = document.getElementsByClassName('tab-content');
        for (var i = 0; i < contents.length; i++) {
            contents[i].classList.remove('active');
        }
        
        var tabs = document.getElementsByClassName('tab');
        for (var i = 0; i < tabs.length; i++) {
            tabs[i].classList.remove('active');
        }
        
        document.getElementById(tabName).classList.add('active');
        event.target.classList.add('active');
    }

    function showDoctorInfo() {
        var select = document.getElementById('doctor_select');
        var selectedOption = select.options[select.selectedIndex];
        
        if (selectedOption.value) {
            document.getElementById('doctor-info').style.display = 'block';
            document.getElementById('doctor-name').textContent = selectedOption.text.split(' - ')[0];
            document.getElementById('doctor-specialization').textContent = selectedOption.getAttribute('data-specialization');
            document.getElementById('doctor-availability').textContent = selectedOption.getAttribute('data-availability');
        } else {
            document.getElementById('doctor-info').style.display = 'none';
        }
    }
    </script>
</body>
</html>